const importsData ={
  "post": [
    6105,
    6155,
    6163,
    6106,
    6164,
    6055,
    6159,
    6058,
    6109,
    6090,
    6017,
    6065,
    6053,
    6056,
    6104,
    6057,
    6018,
    6167,
    6166,
    6054,
    6430,
    6107,
    6112,
    6450,
    6162,
    6165,
    6021,
    6031,
    6168,
    6062,
    6154,
    6102,
    6503,
    6027,
    6160,
    6069,
    6101,
    6220,
    6084,
    6103,
    6262,
    6077,
    6230,
    6229,
    6571,
    6000,
    6123,
    6111,
    6151,
    6210,
    6003,
    6010,
    6121,
    6157,
    6233,
    6064,
    6312,
    6907,
    6019,
    6004,
    6211,
    6280,
    6401,
    6506,
    6714,
    6014,
    6044,
    6125,
    6258,
    6560,
    6059,
    6076,
    6100,
    6147,
    6152,
    6171,
    6172,
    6208,
    6225,
    6228,
    6239,
    6306,
    6375,
    6418,
    6514,
    6920,
    6005,
    6006,
    6007,
    6008,
    6012,
    6016,
    6060,
    6078,
    6150,
    6281,
    6302,
    6521,
    6530,
    6751
  ],
  "vol": [
    43198,
    39648,
    31221,
    30328,
    25692,
    20380,
    19583,
    15019,
    13329,
    10745,
    9900,
    8186,
    6447,
    6061,
    5940,
    5095,
    4491,
    3912,
    3501,
    3260,
    3115,
    2970,
    2873,
    2511,
    2487,
    2487,
    2463,
    1932,
    1690,
    1352,
    1328,
    966,
    869,
    749,
    652,
    555,
    507,
    507,
    483,
    459,
    338,
    314,
    314,
    290,
    290,
    266,
    241,
    217,
    193,
    193,
    169,
    169,
    169,
    169,
    169,
    145,
    145,
    145,
    121,
    97,
    97,
    97,
    97,
    97,
    97,
    72,
    72,
    72,
    72,
    72,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24
  ],
  "suburb": [
    [
      "PERTH AIRPORT",
      "CLOVERDALE",
      "KEWDALE"
    ],
    [
      "WILLETTON",
      "CANNING VALE",
      "CANNING VALE SOUTH",
      "CANNING VALE DC",
      "CANNING VALE EAST"
    ],
    [
      "HILTON",
      "SPEARWOOD",
      "O'CONNOR",
      "BIBRA LAKE DC",
      "KARDINYA",
      "NORTH COOGEE",
      "NORTH LAKE",
      "BIBRA LAKE",
      "HAMILTON HILL",
      "COOLBELLUP",
      "SAMSON"
    ],
    [
      "WELSHPOOL"
    ],
    [
      "COCKBURN CENTRAL",
      "YANGEBUP",
      "ATWELL",
      "HAMMOND PARK",
      "SUCCESS",
      "JANDAKOT",
      "SOUTH LAKE",
      "BEELIAR",
      "AUBIN GROVE",
      "BANJUP"
    ],
    [
      "GUILDFORD",
      "CAVERSHAM",
      "HAZELMERE",
      "HENLEY BROOK",
      "BRABHAM",
      "SOUTH GUILDFORD",
      "DAYTON",
      "WEST SWAN"
    ],
    [
      "NORTH FREMANTLE"
    ],
    [
      "FORRESTFIELD"
    ],
    [
      "MADDINGTON",
      "ORANGE GROVE"
    ],
    [
      "MALAGA"
    ],
    [
      "OSBORNE PARK",
      "OSBORNE PARK DC",
      "HERDSMAN"
    ],
    [
      "MADELEY",
      "PINJAR",
      "GNANGARA",
      "PEARSALL",
      "JANDABUP",
      "WANGARA",
      "DARCH",
      "TAPPING",
      "LANDSDALE",
      "LEXIA",
      "MARIGINIUP",
      "WANNEROO",
      "ASHBY",
      "MELALEUCA",
      "WANGARA DC",
      "HOCKING",
      "KINGSWAY",
      "SINAGRA"
    ],
    [
      "BAYSWATER"
    ],
    [
      "VIVEASH",
      "MIDDLE SWAN",
      "WOODBRIDGE",
      "BOYA",
      "BELLEVUE",
      "MIDLAND",
      "HERNE HILL",
      "BASKERVILLE",
      "RED HILL",
      "GREENMOUNT",
      "MILLENDON",
      "HELENA VALLEY",
      "JANE BROOK",
      "SWAN VIEW",
      "KOONGAMIA",
      "STRATTON",
      "MIDVALE"
    ],
    [
      "REDCLIFFE",
      "ASCOT",
      "BELMONT"
    ],
    [
      "HIGH WYCOMBE",
      "MAIDA VALE"
    ],
    [
      "DOUBLEVIEW",
      "INNALOO",
      "KARRINYUP",
      "GWELUP",
      "WOODLANDS",
      "CHURCHLANDS",
      "GWELUP DC"
    ],
    [
      "BERTRAM",
      "PARMELIA",
      "MEDINA",
      "CALISTA",
      "KWINANA TOWN CENTRE",
      "KWINANA BEACH",
      "ANKETELL",
      "WANDI",
      "CASUARINA",
      "POSTANS",
      "THE SPECTACLES",
      "ORELIA",
      "MANDOGALUP"
    ],
    [
      "HENDERSON",
      "WATTLEUP",
      "MUNSTER",
      "COOGEE"
    ],
    [
      "KIARA",
      "BASSENDEAN",
      "EDEN HILL",
      "LOCKRIDGE",
      "ASHFIELD"
    ],
    [
      "BROADWOOD",
      "SOMERVILLE",
      "WILLIAMSTOWN",
      "HANNANS",
      "PICCADILLY",
      "LAMINGTON",
      "MULLINGAR",
      "WEST LAMINGTON",
      "KALGOORLIE",
      "SOUTH KALGOORLIE",
      "BINDULI",
      "KARLKURLA",
      "WEST KALGOORLIE",
      "YILKARI"
    ],
    [
      "QUEENS PARK",
      "KENWICK",
      "BECKENHAM",
      "WILSON",
      "EAST CANNINGTON",
      "CANNINGTON",
      "WATTLE GROVE"
    ],
    [
      "WUNGONG",
      "HARRISDALE",
      "MOUNT NASURA",
      "HILBERT",
      "ARMADALE",
      "MOUNT RICHON",
      "FORRESTDALE",
      "PIARA WATERS",
      "BROOKDALE",
      "BEDFORDALE",
      "SEVILLE GROVE",
      "HAYNES"
    ],
    [
      "BANDY CREEK",
      "WEST BEACH",
      "EAST MUNGLINUP",
      "CASTLETOWN",
      "SINCLAIR",
      "WINDABOUT",
      "CASCADE",
      "CONDINGUP",
      "MUNGLINUP",
      "PINK LAKE",
      "NERIDUP",
      "MONJINGUP",
      "MYRUP",
      "COOMALBIDGUP",
      "BEAUMONT",
      "CHADWICK",
      "NULSEN",
      "HOWICK",
      "DALYUP",
      "MERIVALE",
      "ESPERANCE",
      "CAPE LE GRAND",
      "BOYATUP"
    ],
    [
      "BEACONSFIELD",
      "SOUTH FREMANTLE",
      "WHITE GUM VALLEY"
    ],
    [
      "HOPE VALLEY",
      "NAVAL BASE"
    ],
    [
      "STIRLING",
      "BALCATTA"
    ],
    [
      "BANKSIA GROVE",
      "CARRAMAR",
      "NEERABUP"
    ],
    [
      "GARDEN ISLAND",
      "EAST ROCKINGHAM",
      "ROCKINGHAM",
      "COOLOONGUP",
      "PERON",
      "HILLMAN",
      "ROCKINGHAM DC",
      "ROCKINGHAM BEACH"
    ],
    [
      "EMBLETON",
      "MORLEY",
      "NORANDA"
    ],
    [
      "BOORAGOON",
      "MYAREE",
      "ALFRED COVE"
    ],
    [
      "BENTLEY",
      "ST JAMES",
      "BENTLEY SOUTH",
      "BENTLEY DC"
    ],
    [
      "GINGIN",
      "WANERIE",
      "YEAL",
      "MOONDAH",
      "RED GULLY",
      "NEERGABBY",
      "GINGINUP",
      "ORANGE SPRINGS",
      "MOORE RIVER NATIONAL PARK",
      "BEERMULLAH",
      "MINDARRA",
      "BAMBUN",
      "MUCKENBURRA",
      "LENNARD BROOK",
      "GRANVILLE",
      "BOONANARRING",
      "CULLALLA",
      "COWALLA",
      "COONABIDGEE",
      "BREERA"
    ],
    [
      "MULLALOO",
      "OCEAN REEF",
      "CONNOLLY",
      "EDGEWATER",
      "JOONDALUP DC",
      "BELDON",
      "HEATHRIDGE",
      "JOONDALUP"
    ],
    [
      "FREMANTLE"
    ],
    [
      "BELHUS",
      "THE VINES",
      "AVELEY",
      "UPPER SWAN",
      "BRIGADOON",
      "ELLENBROOK EAST",
      "ELLENBROOK"
    ],
    [
      "CARLISLE",
      "EAST VICTORIA PARK",
      "CARLISLE SOUTH",
      "CARLISLE NORTH"
    ],
    [
      "MYALUP",
      "WARAWARRUP",
      "COOKERNUP",
      "HARVEY",
      "HOFFMAN",
      "UDUC"
    ],
    [
      "LOWER CHITTERING",
      "AVON VALLEY NATIONAL PARK",
      "CHITTERING",
      "BULLSBROOK",
      "WALYUNGA NATIONAL PARK"
    ],
    [
      "RIVERVALE"
    ],
    [
      "CROWEA",
      "NORTHCLIFFE",
      "WINDY HARBOUR",
      "SHANNON",
      "MEERUP",
      "BOORARA BROOK"
    ],
    [
      "GNANGARA",
      "JANDABUP"
    ],
    [
      "VITTORIA",
      "DALYELLUP",
      "WITHERS",
      "GELORUP",
      "PELICAN POINT",
      "USHER",
      "BUNBURY",
      "GLEN IRIS",
      "SOUTH BUNBURY",
      "COLLEGE GROVE",
      "DAVENPORT",
      "CAREY PARK",
      "EAST BUNBURY"
    ],
    [
      "PICTON EAST",
      "PICTON"
    ],
    [
      "YERECOIN"
    ],
    [
      "PERTH",
      "PERTH GPO",
      "CITY DELIVERY CENTRE"
    ],
    [
      "MUNDIJONG",
      "WHITBY"
    ],
    [
      "CANNING MILLS",
      "WESTFIELD",
      "ASHENDON",
      "ROLEYSTONE",
      "KARRAGULLEN",
      "KELMSCOTT DC",
      "LESLEY",
      "CHAMPION LAKES",
      "CAMILLO",
      "KELMSCOTT"
    ],
    [
      "SOUTH PERTH ANGELO ST",
      "SOUTH PERTH",
      "KENSINGTON"
    ],
    [
      "FURNISSDALE",
      "SILVER SANDS",
      "DAWESVILLE",
      "ERSKINE",
      "STAKE HILL",
      "BARRAGUP",
      "WANNANUP",
      "HERRON",
      "DUDLEY PARK",
      "SAN REMO",
      "CLIFTON",
      "COODANUP",
      "MEADOW SPRINGS",
      "FALCON",
      "MADORA BAY",
      "PARKLANDS",
      "LAKELANDS",
      "BOUVARD",
      "MANDURAH DC",
      "MANDURAH",
      "MANDURAH EAST",
      "HALLS HEAD",
      "GREENFIELDS",
      "MANDURAH NORTH"
    ],
    [
      "HIGHGATE",
      "NORTHBRIDGE"
    ],
    [
      "CLAREMONT",
      "SWANBOURNE",
      "KARRAKATTA",
      "MOUNT CLAREMONT",
      "CLAREMONT NORTH"
    ],
    [
      "OAKFORD",
      "OLDBURY"
    ],
    [
      "PALMYRA",
      "BICTON",
      "PALMYRA DC"
    ],
    [
      "WELLESLEY",
      "AUSTRALIND",
      "LESCHENAULT",
      "BINNINGUP",
      "PARKFIELD"
    ],
    [
      "MARANGAROO",
      "KOONDOOLA",
      "ALEXANDER HEIGHTS",
      "GIRRAWHEEN"
    ],
    [
      "NARROGIN",
      "YILLIMINNING",
      "NOMANS LAKE",
      "TOOLIBIN",
      "DUMBERNING",
      "BOUNDAIN",
      "NARROGIN VALLEY",
      "MINIGIN",
      "HILLSIDE"
    ],
    [
      "NEDLANDS"
    ],
    [
      "WEMBLEY DOWNS",
      "SCARBOROUGH"
    ],
    [
      "EAST PERTH"
    ],
    [
      "DAWESVILLE",
      "HERRON",
      "CLIFTON",
      "BOUVARD"
    ],
    [
      "BUSSELTON",
      "ABBEY",
      "WONNERUP",
      "YELVERTON",
      "LUDLOW",
      "GEOGRAPHE",
      "CARBUNUP RIVER",
      "YOONGARILLUP",
      "YALYALUP",
      "BOVELL",
      "METRICUP",
      "AMBERGATE",
      "KALGUP",
      "SIESTA PARK",
      "REINSCOURT",
      "NORTH JINDONG",
      "BROADWATER",
      "KEALY",
      "VASSE",
      "ANNIEBROOK",
      "SABINA RIVER",
      "RUABON",
      "KALOORUP",
      "JINDONG",
      "HITHERGREEN",
      "WALSALL",
      "TUTUNUP",
      "BOALLIA",
      "ACTON PARK",
      "ABBA RIVER",
      "WILYABRUP",
      "MARYBROOK",
      "CHAPMAN HILL",
      "WEST BUSSELTON"
    ],
    [
      "MURESK",
      "WONGAMINE",
      "JENNAPULLIN",
      "SPENCERS BROOK",
      "NORTHAM",
      "JENNACUBBINE",
      "SOUTHERN BROOK",
      "MULUCKINE",
      "CUNJARDINE",
      "THROSSELL",
      "ROSSMORE",
      "MUMBERKINE",
      "MEENAAR",
      "MALABAINE",
      "IRISHTOWN",
      "BURLONG",
      "BUCKLAND",
      "MOKINE"
    ],
    [
      "MOGUMBER"
    ],
    [
      "MULATAGA",
      "BULGARRA",
      "BURRUP",
      "CLEAVERVILLE",
      "BAYNTON",
      "PEGS CREEK",
      "NICKOL",
      "KARRATHA",
      "MILLARS WELL",
      "SHERLOCK",
      "MARDIE",
      "COOYA POOYA",
      "GNOOREA",
      "ANTONYMYRE",
      "KARRATHA INDUSTRIAL ESTATE",
      "GAP RIDGE",
      "STOVE HILL",
      "BALLA BALLA",
      "MOUNT ANKETELL",
      "MAITLAND"
    ],
    [
      "JOLIMONT",
      "FLOREAT",
      "WEMBLEY"
    ],
    [
      "LANCELIN",
      "NILGEN",
      "WEDGE ISLAND",
      "KARAKIN"
    ],
    [
      "SERPENTINE",
      "MARDELLA",
      "HOPELAND"
    ],
    [
      "YANMAH",
      "PALGARUP",
      "SMITH BROOK",
      "BALBARRUP",
      "SHANNON RIVER MILL",
      "MANJIMUP",
      "RINGBARK",
      "LAKE MUIR",
      "WILGARRUP",
      "DIAMOND TREE",
      "DEANMILL",
      "MIDDLESEX",
      "QUINNINUP",
      "MORDALUP",
      "UPPER WARREN",
      "NYAMUP",
      "JARDEE",
      "PERUP",
      "LINFARNE",
      "GLENORAN",
      "DINGUP",
      "CROWEA",
      "DONNELLY RIVER",
      "DIXVALE"
    ],
    [
      "WUNDOWIE"
    ],
    [
      "DIANELLA"
    ],
    [
      "WALLISTON",
      "LESMURDIE",
      "PICKERING BROOK",
      "PIESSE BROOK",
      "PAULLS VALLEY",
      "RESERVOIR",
      "GOOSEBERRY HILL",
      "BICKLEY",
      "CARMEL",
      "HACKETTS GULLY",
      "KALAMUNDA"
    ],
    [
      "LATHLAIN",
      "BURSWOOD",
      "VICTORIA PARK"
    ],
    [
      "PARKWOOD",
      "LANGFORD",
      "LYNWOOD"
    ],
    [
      "MANNING",
      "SALTER POINT",
      "WATERFORD",
      "KARAWARA",
      "COMO"
    ],
    [
      "BALDIVIS"
    ],
    [
      "PORT KENNEDY"
    ],
    [
      "SOUTH YUNDERUP",
      "MEELON",
      "NORTH YUNDERUP",
      "RAVENSWOOD",
      "BLYTHEWOOD",
      "PINJARRA",
      "POINT GREY",
      "NIRIMBA",
      "FAIRBRIDGE",
      "OAKLEY",
      "WEST PINJARRA"
    ],
    [
      "MUMBALLUP",
      "NOGGERUP",
      "COLLIE",
      "SHOTTS",
      "WORSLEY",
      "MUNGALUP",
      "ALLANSON",
      "PALMER",
      "COLLIE BURN",
      "YOURDAMUNG LAKE",
      "CARDIFF",
      "BOWELLING",
      "BUCKINGHAM",
      "MCALINDEN",
      "MUJA",
      "HARRIS RIVER",
      "PRESTON SETTLEMENT",
      "LYALLS MILL"
    ],
    [
      "WATERLOO"
    ],
    [
      "DONNYBROOK",
      "ARGYLE",
      "BEELERUP",
      "THOMSON BROOK",
      "YABBERUP",
      "QUEENWOOD",
      "PAYNEDALE",
      "GLEN MERVYN",
      "CHARLEY CREEK",
      "BROOKHAMPTON",
      "UPPER CAPEL"
    ],
    [
      "BROOKTON",
      "BULYEE",
      "KWEDA",
      "ALDERSYDE",
      "JELCOBINE"
    ],
    [
      "BILBARIN",
      "KUNJIN",
      "KURRENKUTTEN",
      "CORRIGIN",
      "ADAMSVALE",
      "GORGE ROCK"
    ],
    [
      "BRUCE ROCK",
      "YARDING"
    ],
    [
      "GREEN HEAD",
      "LEEMAN"
    ],
    [
      "NORTH BEACH"
    ],
    [
      "WEST PERTH",
      "KINGS PARK"
    ],
    [
      "NORTH PERTH"
    ],
    [
      "WEST LEEDERVILLE",
      "LEEDERVILLE"
    ],
    [
      "SHENTON PARK",
      "SUBIACO",
      "DAGLISH",
      "SUBIACO EAST"
    ],
    [
      "MOSMAN PARK"
    ],
    [
      "GLENDALOUGH",
      "MOUNT HAWTHORN"
    ],
    [
      "JOONDANNA",
      "YOKINE SOUTH",
      "YOKINE",
      "TUART HILL",
      "DOG SWAMP"
    ],
    [
      "MARIGINIUP",
      "PINJAR"
    ],
    [
      "BATEMAN",
      "WINTHROP",
      "MURDOCH"
    ],
    [
      "QUEDJINUP",
      "DUNSBOROUGH",
      "QUINDALUP",
      "NATURALISTE",
      "EAGLE BAY"
    ],
    [
      "FLINT",
      "YORK",
      "GREENHILLS",
      "MOUNT HARDEY",
      "FLYNN",
      "BURGES",
      "MALEBELLING",
      "GWAMBYGINE",
      "TALBOT WEST",
      "INKPEN",
      "TALBOT",
      "WILBERFORCE",
      "GILGERING",
      "ST RONANS",
      "QUELLINGTON",
      "NARRALOGGAN",
      "MOUNT OBSERVATION",
      "KAURING",
      "DALIAK",
      "COLD HARBOUR",
      "CALJIE",
      "BALLADONG",
      "BADGIN"
    ],
    [
      "GREY",
      "BOOTHENDARRA",
      "NAMBUNG",
      "BADGINGARRA",
      "HILL RIVER"
    ],
    [
      "BEACHLANDS",
      "MAHOMETS FLATS",
      "WONTHELLA",
      "GERALDTON",
      "WEBBERTON",
      "MERU",
      "BERESFORD",
      "WAGGRAKINE",
      "TARCOOLA BEACH",
      "RANGEWAY",
      "BLUFF POINT",
      "KARLOO",
      "SUNSET BEACH",
      "SPALDING",
      "MOUNT TARCOOLA",
      "MORESBY",
      "HOUTMAN ABROLHOS",
      "WEST END",
      "WOORREE",
      "WANDINA",
      "STRATHALBYN",
      "UTAKARRA"
    ],
    [
      "TOM PRICE",
      "CHICHESTER",
      "WITTENOOM",
      "ROCKLEA",
      "KARIJINI",
      "NANUTARRA",
      "MULGA DOWNS",
      "MOUNT SHEILA",
      "JUNA DOWNS",
      "INNAWANGA"
    ]
  ]
};

  const exportsData = {
  "post": [
    6058,
    6167,
    6312,
    6159,
    6105,
    6163,
    6302,
    6155,
    6220,
    6438,
    6017,
    6571,
    6055,
    6090,
    6233,
    6165,
    6430,
    6112,
    6056,
    6106,
    6229,
    6254,
    6102,
    6065,
    6642,
    6505,
    6306,
    6168,
    6069,
    6031,
    6164,
    6166,
    6021,
    6109,
    6054,
    6057,
    6053,
    6107,
    6401,
    6101,
    6061,
    6100,
    6147,
    6208,
    6230,
    6509,
    6014,
    6556
  ],
  "vol": [
    50101,
    19884,
    19317,
    15945,
    10657,
    10468,
    10360,
    7851,
    7662,
    7419,
    6313,
    6151,
    5423,
    4775,
    4425,
    4236,
    3858,
    3211,
    1916,
    1646,
    1619,
    1619,
    1268,
    1160,
    1079,
    917,
    863,
    809,
    540,
    459,
    459,
    432,
    405,
    297,
    270,
    270,
    216,
    135,
    108,
    81,
    54,
    54,
    54,
    54,
    54,
    54,
    27,
    27
  ],
  "suburb": [
    [
      "FORRESTFIELD"
    ],
    [
      "BERTRAM",
      "PARMELIA",
      "MEDINA",
      "CALISTA",
      "KWINANA TOWN CENTRE",
      "KWINANA BEACH",
      "ANKETELL",
      "WANDI",
      "CASUARINA",
      "POSTANS",
      "THE SPECTACLES",
      "ORELIA",
      "MANDOGALUP"
    ],
    [
      "NARROGIN",
      "YILLIMINNING",
      "NOMANS LAKE",
      "TOOLIBIN",
      "DUMBERNING",
      "BOUNDAIN",
      "NARROGIN VALLEY",
      "MINIGIN",
      "HILLSIDE"
    ],
    [
      "NORTH FREMANTLE"
    ],
    [
      "PERTH AIRPORT",
      "CLOVERDALE",
      "KEWDALE"
    ],
    [
      "HILTON",
      "SPEARWOOD",
      "O'CONNOR",
      "BIBRA LAKE DC",
      "KARDINYA",
      "NORTH COOGEE",
      "NORTH LAKE",
      "BIBRA LAKE",
      "HAMILTON HILL",
      "COOLBELLUP",
      "SAMSON"
    ],
    [
      "FLINT",
      "YORK",
      "GREENHILLS",
      "MOUNT HARDEY",
      "FLYNN",
      "BURGES",
      "MALEBELLING",
      "GWAMBYGINE",
      "TALBOT WEST",
      "INKPEN",
      "TALBOT",
      "WILBERFORCE",
      "GILGERING",
      "ST RONANS",
      "QUELLINGTON",
      "NARRALOGGAN",
      "MOUNT OBSERVATION",
      "KAURING",
      "DALIAK",
      "COLD HARBOUR",
      "CALJIE",
      "BALLADONG",
      "BADGIN"
    ],
    [
      "WILLETTON",
      "CANNING VALE",
      "CANNING VALE SOUTH",
      "CANNING VALE DC",
      "CANNING VALE EAST"
    ],
    [
      "MYALUP",
      "WARAWARRUP",
      "COOKERNUP",
      "HARVEY",
      "HOFFMAN",
      "UDUC"
    ],
    [
      "LEONORA",
      "LAKE DARLOT"
    ],
    [
      "OSBORNE PARK",
      "OSBORNE PARK DC",
      "HERDSMAN"
    ],
    [
      "YERECOIN"
    ],
    [
      "GUILDFORD",
      "CAVERSHAM",
      "HAZELMERE",
      "HENLEY BROOK",
      "BRABHAM",
      "SOUTH GUILDFORD",
      "DAYTON",
      "WEST SWAN"
    ],
    [
      "MALAGA"
    ],
    [
      "WELLESLEY",
      "AUSTRALIND",
      "LESCHENAULT",
      "BINNINGUP",
      "PARKFIELD"
    ],
    [
      "HOPE VALLEY",
      "NAVAL BASE"
    ],
    [
      "BROADWOOD",
      "SOMERVILLE",
      "WILLIAMSTOWN",
      "HANNANS",
      "PICCADILLY",
      "LAMINGTON",
      "MULLINGAR",
      "WEST LAMINGTON",
      "KALGOORLIE",
      "SOUTH KALGOORLIE",
      "BINDULI",
      "KARLKURLA",
      "WEST KALGOORLIE",
      "YILKARI"
    ],
    [
      "WUNGONG",
      "HARRISDALE",
      "MOUNT NASURA",
      "HILBERT",
      "ARMADALE",
      "MOUNT RICHON",
      "FORRESTDALE",
      "PIARA WATERS",
      "BROOKDALE",
      "BEDFORDALE",
      "SEVILLE GROVE",
      "HAYNES"
    ],
    [
      "VIVEASH",
      "MIDDLE SWAN",
      "WOODBRIDGE",
      "BOYA",
      "BELLEVUE",
      "MIDLAND",
      "HERNE HILL",
      "BASKERVILLE",
      "RED HILL",
      "GREENMOUNT",
      "MILLENDON",
      "HELENA VALLEY",
      "JANE BROOK",
      "SWAN VIEW",
      "KOONGAMIA",
      "STRATTON",
      "MIDVALE"
    ],
    [
      "WELSHPOOL"
    ],
    [
      "PICTON EAST",
      "PICTON"
    ],
    [
      "GREENBUSHES",
      "NORTH GREENBUSHES"
    ],
    [
      "BENTLEY",
      "ST JAMES",
      "BENTLEY SOUTH",
      "BENTLEY DC"
    ],
    [
      "MADELEY",
      "PINJAR",
      "GNANGARA",
      "PEARSALL",
      "JANDABUP",
      "WANGARA",
      "DARCH",
      "TAPPING",
      "LANDSDALE",
      "LEXIA",
      "MARIGINIUP",
      "WANNEROO",
      "ASHBY",
      "MELALEUCA",
      "WANGARA DC",
      "HOCKING",
      "KINGSWAY",
      "SINAGRA"
    ],
    [
      "MEEKATHARRA",
      "PEAK HILL",
      "KARALUNDI",
      "CAPRICORN",
      "KUMARINA",
      "ANGELO RIVER"
    ],
    [
      "WANNAMAL"
    ],
    [
      "BROOKTON",
      "BULYEE",
      "KWEDA",
      "ALDERSYDE",
      "JELCOBINE"
    ],
    [
      "GARDEN ISLAND",
      "EAST ROCKINGHAM",
      "ROCKINGHAM",
      "COOLOONGUP",
      "PERON",
      "HILLMAN",
      "ROCKINGHAM DC",
      "ROCKINGHAM BEACH"
    ],
    [
      "BELHUS",
      "THE VINES",
      "AVELEY",
      "UPPER SWAN",
      "BRIGADOON",
      "ELLENBROOK EAST",
      "ELLENBROOK"
    ],
    [
      "BANKSIA GROVE",
      "CARRAMAR",
      "NEERABUP"
    ],
    [
      "COCKBURN CENTRAL",
      "YANGEBUP",
      "ATWELL",
      "HAMMOND PARK",
      "SUCCESS",
      "JANDAKOT",
      "SOUTH LAKE",
      "BEELIAR",
      "AUBIN GROVE",
      "BANJUP"
    ],
    [
      "HENDERSON",
      "WATTLEUP",
      "MUNSTER",
      "COOGEE"
    ],
    [
      "STIRLING",
      "BALCATTA"
    ],
    [
      "MADDINGTON",
      "ORANGE GROVE"
    ],
    [
      "KIARA",
      "BASSENDEAN",
      "EDEN HILL",
      "LOCKRIDGE",
      "ASHFIELD"
    ],
    [
      "HIGH WYCOMBE",
      "MAIDA VALE"
    ],
    [
      "BAYSWATER"
    ],
    [
      "QUEENS PARK",
      "KENWICK",
      "BECKENHAM",
      "WILSON",
      "EAST CANNINGTON",
      "CANNINGTON",
      "WATTLE GROVE"
    ],
    [
      "MURESK",
      "WONGAMINE",
      "JENNAPULLIN",
      "SPENCERS BROOK",
      "NORTHAM",
      "JENNACUBBINE",
      "SOUTHERN BROOK",
      "MULUCKINE",
      "CUNJARDINE",
      "THROSSELL",
      "ROSSMORE",
      "MUMBERKINE",
      "MEENAAR",
      "MALABAINE",
      "IRISHTOWN",
      "BURLONG",
      "BUCKLAND",
      "MOKINE"
    ],
    [
      "CARLISLE",
      "EAST VICTORIA PARK",
      "CARLISLE SOUTH",
      "CARLISLE NORTH"
    ],
    [
      "MIRRABOOKA",
      "WESTMINSTER",
      "NOLLAMARA",
      "BALGA"
    ],
    [
      "LATHLAIN",
      "BURSWOOD",
      "VICTORIA PARK"
    ],
    [
      "PARKWOOD",
      "LANGFORD",
      "LYNWOOD"
    ],
    [
      "SOUTH YUNDERUP",
      "MEELON",
      "NORTH YUNDERUP",
      "RAVENSWOOD",
      "BLYTHEWOOD",
      "PINJARRA",
      "POINT GREY",
      "NIRIMBA",
      "FAIRBRIDGE",
      "OAKLEY",
      "WEST PINJARRA"
    ],
    [
      "VITTORIA",
      "DALYELLUP",
      "WITHERS",
      "GELORUP",
      "PELICAN POINT",
      "USHER",
      "BUNBURY",
      "GLEN IRIS",
      "SOUTH BUNBURY",
      "COLLEGE GROVE",
      "DAVENPORT",
      "CAREY PARK",
      "EAST BUNBURY"
    ],
    [
      "NEW NORCIA",
      "YARAWINDAH",
      "WADDINGTON",
      "GLENTROMIE"
    ],
    [
      "JOLIMONT",
      "FLOREAT",
      "WEMBLEY"
    ],
    [
      "BEECHINA",
      "GORRIE",
      "THE LAKES",
      "CHIDLOW",
      "MALMALLING"
    ]
  ]
};